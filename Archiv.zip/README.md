# how-much-btc

## Next Steps

- < 1.000.000 sats —> sats
- Variante von "23 von 40"
- Firefox compatibility?

## Links

### Cross Compatibility

https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Chrome_incompatibilities
https://github.com/mozilla/webextension-polyfill/
